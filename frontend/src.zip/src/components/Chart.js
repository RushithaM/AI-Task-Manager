import React, { useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  ArcElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
  PieController,
  BarController,
  LineController,
  BarElement,
  PointElement,
  LineElement,
} from 'chart.js';
import { Pie, Bar, Line } from 'react-chartjs-2';
import './Chart.css';

// Register the necessary components
ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
  PieController,
  BarController,
  LineController,
  BarElement,
  PointElement,
  LineElement
);

function Chart({ tasks }) {
  // Create refs for each chart
  const pieChartRef = useRef(null);
  const barChartRef = useRef(null);
  const lineChartRef = useRef(null);

  // Prepare data for priority distribution (Pie Chart)
  const priorityData = {
    labels: ['P0', 'P1', 'P2'],
    datasets: [{
      data: [
        tasks.filter(task => task.priority === 'P0').length,
        tasks.filter(task => task.priority === 'P1').length,
        tasks.filter(task => task.priority === 'P2').length
      ],
      backgroundColor: ['#ef4444', '#f59e0b', '#10b981'],
      hoverOffset: 4
    }]
  };

  // Prepare data for SP comparison (Bar Chart)
  const spData = {
    labels: tasks.map(task => task.title ? task.title.substring(0, 10) + '...' : 'Unnamed Task'),
    datasets: [
      {
        label: 'Assigned SP',
        data: tasks.map(task => task.sp_assigned || 0),
        backgroundColor: '#3b82f6',
      },
      {
        label: 'Actual SP',
        data: tasks.map(task => task.sp_actual || 0),
        backgroundColor: '#8b5cf6',
      }
    ]
  };

  // Prepare data for completion trends (Line Chart)
  const sortedTasks = [...tasks].sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
  const completionData = {
    labels: sortedTasks.map(task => new Date(task.due_date).toLocaleDateString()),
    datasets: [{
      label: 'Completed Tasks',
      data: sortedTasks.map((_, index) => sortedTasks.slice(0, index + 1).filter(task => task.status === 'Completed').length),
      borderColor: '#10b981',
      tension: 0.1
    }]
  };

  // Check if tasks is defined and has elements
  const hasTasks = tasks && tasks.length > 0;

  useEffect(() => {
    // Cleanup function to destroy the chart instances
    return () => {
      if (pieChartRef.current) {
        pieChartRef.current.destroy();
      }
      if (barChartRef.current) {
        barChartRef.current.destroy();
      }
      if (lineChartRef.current) {
        lineChartRef.current.destroy();
      }
    };
  }, [tasks]); // Run this effect when tasks change

  if (!hasTasks) {
    return <div>No tasks available</div>;
  }

  return (
    <div className="charts-container">
      <div className="chart-wrapper">
        <h3>Priority Distribution</h3>
        <Pie ref={pieChartRef} data={priorityData} options={{ responsive: true, maintainAspectRatio: false }} />
      </div>
      <div className="chart-wrapper">
        <h3>SP Comparison</h3>
        <Bar ref={barChartRef} data={spData} options={{ responsive: true, maintainAspectRatio: false }} />
      </div>
      <div className="chart-wrapper">
        <h3>Completion Trends</h3>
        <Line ref={lineChartRef} data={completionData} options={{ responsive: true, maintainAspectRatio: false }} />
      </div>
    </div>
  );
}

export default Chart;